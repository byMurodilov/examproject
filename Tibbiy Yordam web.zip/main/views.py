from django.shortcuts import render

from . import models


def index(request):
    if request.method == 'POST':
        f_name = request.POST.get('f_name')
        l_name = request.POST.get('l_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        body = request.POST.get("body")
        models.Contact.objects.create(
            f_name = f_name,
            l_name = l_name,
            email = email,
            phone =  phone,
            body = body
        )
    return render(request, 'index.html')


def contact(request):
    if request.method == 'POST':
        try:
            models.Contact.objects.create( 
                f_name = request.POST['f_name'],
                l_name = request.POST['l_name'],
                phone = request.POST['phone'],
                email = request.POST['email'],
                body = request.POST['body']
             )
        except:
            ...
    return render(request, 'contact.html')