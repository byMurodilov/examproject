from django.db import models


class Contact(models.Model):
    f_name = models.CharField(max_length=255)
    l_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)
    email = models.EmailField(blank=True, null=True)
    body = models.TextField()
    is_show = models.BooleanField(default=False)
